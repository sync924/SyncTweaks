@echo off
title Sync Tweaks v1
color 0B

:MENU
cls
echo =====================================
echo          SYNC TWEAKS v1
echo =====================================
echo.
echo [1] Apply performance tweaks
echo [2] Clean temporary files
echo [3] Enable Windows Game Mode
echo [4] Restore power settings
echo [5] Exit
echo.
set /p choice=Choose an option: 

if "%choice%"=="1" goto PERFORMANCE
if "%choice%"=="2" goto CLEAN
if "%choice%"=="3" goto GAMEMODE
if "%choice%"=="4" goto RESTORE
if "%choice%"=="5" exit
goto MENU

:PERFORMANCE
cls
echo Applying performance settings...
echo.

powercfg /setactive SCHEME_MIN

echo High Performance power plan enabled.
echo.

echo Disabling Game DVR background recording...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled /t REG_DWORD /d 0 /f

echo.
echo Performance tweaks applied.
echo Restart Windows for the changes to fully take effect.
pause
goto MENU

:CLEAN
cls
echo Cleaning temporary files...
echo.

del /q /f "%TEMP%\*" >nul 2>&1
for /d %%D in ("%TEMP%\*") do rd /s /q "%%D" >nul 2>&1

echo Temporary files cleaned.
pause
goto MENU

:GAMEMODE
cls
echo Enabling Windows Game Mode...

reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f

echo.
echo Game Mode setting enabled.
pause
goto MENU

:RESTORE
cls
echo Restoring normal Windows power settings...
echo.

powercfg /setactive SCHEME_BALANCED

echo Balanced power plan restored.
pause
goto MENU